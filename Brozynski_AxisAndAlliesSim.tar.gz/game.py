from army import *
from territory import *
from nation import *
import europe1940

boardSetup=europe1940.europe1940()
territoryDict = boardSetup.territoryDict

class game:
 

 def __init__(self):
  players=boardSetup.players
  
